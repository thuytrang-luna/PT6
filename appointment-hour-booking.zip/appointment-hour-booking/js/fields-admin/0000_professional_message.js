$.fbuilder.categoryList[2]={
		title : "",
		description : ""
        /*"<div style=\"padding: 10px; background-color: #ffffdd; border: 1px solid #e6e6e6; border-radius: 6px; margin-top: 20px;margin-bottom:20px;\"><p style=\"text-align:center;\"><button type=\"button\" onclick=\"window.open('https://apphourbooking.dwbooster.com/download?src=activatebtn');\" class=\"button-primary\">Activate the FULL form builder</button></p><p style=\"font-weight:bold\">The full form builder also includes:</p><ul><li> - Full set of fields, <strong>conditional logic</strong>, file <strong>uploads</strong>, multi-page forms</li><li> - <strong>Payments integration</strong>, all <strong>addons</strong> (iCal sync, SMS, reminders, cancellation opts, reCaptcha, MailChimp, ...), etc...</li></ul></div>"*/
	};
