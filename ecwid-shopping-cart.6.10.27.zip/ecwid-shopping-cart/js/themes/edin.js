jQuery(document).ready(function() {

	jQuery('.ecwid-store-with-categories a').click(function() {
		jQuery('button.menu-toggle.open').click()
	})

});