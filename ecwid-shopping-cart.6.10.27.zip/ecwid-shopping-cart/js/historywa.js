if (!window.History.options) window.History.options = {};
window.History.options.html4Mode=1;
