<div class="text-default warning" data-ec-state="draft">
	<b><?php _e( 'Publish the page to use this option', 'ecwid-shopping-cart' );?></b>
</div>