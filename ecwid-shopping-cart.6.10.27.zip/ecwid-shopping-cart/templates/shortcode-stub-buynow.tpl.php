<div class="ec-store-block ec-store-block-buynow">
	<div class="image"></div>
</div>