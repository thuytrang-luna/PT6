<div class="ecwid-popup <?php echo esc_html($this->_class); ?>">
	<div class="ecwid-popup-window">
		<div class="ecwid-popup-header">
			<?php $this->_render_header(); ?>
		</div>
		<div class="ecwid-popup-body">
			<?php $this->_render_body(); ?>
		</div>
		<div class="ecwid-popup-footer">
			<?php $this->_render_footer(); ?>
		</div>
	</div>
</div>